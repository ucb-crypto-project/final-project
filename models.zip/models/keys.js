console.log('this is loaded');

var binanceKeys = binance.options({
  api_key:'<api key>',
  api_secret:'<api secret>'
});

module.exports = binanceKeys;
