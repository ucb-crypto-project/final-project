const binance = require('node-binance-api');
var fs = require("fs");
var keys = require('./keys.js');
var request = require('request');


var runBinance = function() {
  var binanceCoins = new BinanceCoins({
  'APIKEY': keys.api_key,
  'APISECRET': keys.api_secret,
  });

  var path = 'https://api.binance.com/api/v3/ticker/price';

  binanceCoins.get(path, function(error, response){
    if(error) {
      console.log(error);
    }
    console.log(response);
  });
}
runBinance();

module.exports = Coin;

// module.exports = {
//   findCoins: function(req, res) {
//     binance.prices((error, ticker) => {
//           console.log("prices()", ticket);
//           console.log("Price of BNB: ", ticker.BNBBTC);
//         });
//   }
// }

// binance.options({
//   'APIKEY':'<api key>',
//   'APISECRET':'<api secret>'
// });
